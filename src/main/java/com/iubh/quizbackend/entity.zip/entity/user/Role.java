package com.iubh.quizbackend.entity.user;

public enum Role {
    ADMIN,
    STUDENT
}
