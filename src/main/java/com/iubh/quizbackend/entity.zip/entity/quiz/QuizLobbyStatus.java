package com.iubh.quizbackend.entity.quiz;

public enum QuizLobbyStatus {
    WAITING,
    IN_PROGRESS,
    FINISHED,
    CANCELLED
}