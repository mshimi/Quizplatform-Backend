package com.iubh.quizbackend.entity.question;

public enum ChoiceQuestionType {
    SINGLE,
    MULTI
}
